"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const Onboarding = ({ onComplete }) => {
    const [formData, setFormData] = (0, react_1.useState)({
        name: '',
        email: '',
        codingLevel: 'i-dont-know-what-im-doing',
        agreedToTerms: false
    });
    const [currentStep, setCurrentStep] = (0, react_1.useState)(0);
    // Debug logging
    console.log('Onboarding component state:', { currentStep, formData });
    const handleSubmit = (e) => {
        e.preventDefault();
        onComplete(formData);
    };
    const nextStep = () => setCurrentStep(prev => Math.min(prev + 1, 4));
    const prevStep = () => setCurrentStep(prev => Math.max(prev - 1, 0));
    const renderStep = () => {
        switch (currentStep) {
            case 0:
                return ((0, jsx_runtime_1.jsxs)("div", { className: "onboarding-step", children: [(0, jsx_runtime_1.jsx)("h1", { children: "Welcome to \"i cant code\"!" }), (0, jsx_runtime_1.jsx)("p", { className: "subtitle", children: "Don't worry, that's exactly why you're here!" }), (0, jsx_runtime_1.jsxs)("div", { className: "fun-facts", children: [(0, jsx_runtime_1.jsxs)("p", { children: [(0, jsx_runtime_1.jsx)("strong", { children: "Fun fact:" }), " 73% of developers still Google \"how to center a div\""] }), (0, jsx_runtime_1.jsxs)("p", { children: [(0, jsx_runtime_1.jsx)("strong", { children: "Another fact:" }), " Maybe you should just learn how to code and stop vibe coding"] }), (0, jsx_runtime_1.jsxs)("p", { children: [(0, jsx_runtime_1.jsx)("strong", { children: "Good news:" }), " You're about to get AI-powered code explanations!"] })] }), (0, jsx_runtime_1.jsx)("button", { onClick: nextStep, className: "next-btn", children: "Let's Get Started!" })] }));
            case 1:
                return ((0, jsx_runtime_1.jsxs)("div", { className: "onboarding-step", children: [(0, jsx_runtime_1.jsx)("h2", { children: "What should we call you?" }), (0, jsx_runtime_1.jsx)("p", { children: "We promise not to judge your coding skills... much" }), (0, jsx_runtime_1.jsx)("input", { type: "text", placeholder: "Your name (or whatever you want to be called)", value: formData.name, onChange: (e) => setFormData({ ...formData, name: e.target.value }), className: "input-field" }), (0, jsx_runtime_1.jsxs)("div", { className: "button-group", children: [(0, jsx_runtime_1.jsx)("button", { onClick: prevStep, className: "back-btn", children: "\u2190 Back" }), (0, jsx_runtime_1.jsx)("button", { onClick: nextStep, className: "next-btn", disabled: !formData.name.trim(), children: "Next \u2192" })] })] }));
            case 2:
                return ((0, jsx_runtime_1.jsxs)("div", { className: "onboarding-step", children: [(0, jsx_runtime_1.jsx)("h2", { children: "Stay in the loop!" }), (0, jsx_runtime_1.jsx)("p", { children: "Get updates about new features and tips." }), (0, jsx_runtime_1.jsx)("input", { type: "email", placeholder: "your.email@example.com", value: formData.email, onChange: (e) => setFormData({ ...formData, email: e.target.value }), className: "input-field" }), (0, jsx_runtime_1.jsxs)("div", { className: "button-group", children: [(0, jsx_runtime_1.jsx)("button", { onClick: prevStep, className: "back-btn", children: "\u2190 Back" }), (0, jsx_runtime_1.jsx)("button", { onClick: nextStep, className: "next-btn", disabled: !formData.email.trim(), children: "Next \u2192" })] })] }));
            case 3:
                return ((0, jsx_runtime_1.jsxs)("div", { className: "onboarding-step", children: [(0, jsx_runtime_1.jsx)("h2", { children: "How would you rate your coding skills?" }), (0, jsx_runtime_1.jsx)("p", { children: "Be honest - we're all friends here!" }), (0, jsx_runtime_1.jsxs)("div", { className: "coding-level-options", children: [(0, jsx_runtime_1.jsxs)("label", { className: "option", children: [(0, jsx_runtime_1.jsx)("input", { type: "radio", name: "codingLevel", value: "beginner", checked: formData.codingLevel === 'beginner', onChange: (e) => {
                                                console.log('Selected coding level:', e.target.value);
                                                setFormData({ ...formData, codingLevel: e.target.value });
                                            } }), (0, jsx_runtime_1.jsx)("span", { children: "Beginner - \"What is a variable?\"" })] }), (0, jsx_runtime_1.jsxs)("label", { className: "option", children: [(0, jsx_runtime_1.jsx)("input", { type: "radio", name: "codingLevel", value: "intermediate", checked: formData.codingLevel === 'intermediate', onChange: (e) => {
                                                console.log('Selected coding level:', e.target.value);
                                                setFormData({ ...formData, codingLevel: e.target.value });
                                            } }), (0, jsx_runtime_1.jsx)("span", { children: "Intermediate - \"I can center a div... sometimes\"" })] }), (0, jsx_runtime_1.jsxs)("label", { className: "option", children: [(0, jsx_runtime_1.jsx)("input", { type: "radio", name: "codingLevel", value: "expert", checked: formData.codingLevel === 'expert', onChange: (e) => {
                                                console.log('Selected coding level:', e.target.value);
                                                setFormData({ ...formData, codingLevel: e.target.value });
                                            } }), (0, jsx_runtime_1.jsx)("span", { children: "Expert - \"I write code that even I can't understand\"" })] }), (0, jsx_runtime_1.jsxs)("label", { className: "option", children: [(0, jsx_runtime_1.jsx)("input", { type: "radio", name: "codingLevel", value: "i-dont-know-what-im-doing", checked: formData.codingLevel === 'i-dont-know-what-im-doing', onChange: (e) => {
                                                console.log('Selected coding level:', e.target.value);
                                                setFormData({ ...formData, codingLevel: e.target.value });
                                            } }), (0, jsx_runtime_1.jsx)("span", { children: "\"I don't know what I'm doing\" - The honest choice!" })] })] }), (0, jsx_runtime_1.jsxs)("div", { className: "button-group", children: [(0, jsx_runtime_1.jsx)("button", { onClick: prevStep, className: "back-btn", children: "\u2190 Back" }), (0, jsx_runtime_1.jsx)("button", { onClick: nextStep, className: "next-btn", disabled: !formData.codingLevel, style: { opacity: formData.codingLevel ? 1 : 0.5 }, children: "Almost Done! \u2192" })] }), (0, jsx_runtime_1.jsxs)("div", { style: { marginTop: '20px', fontSize: '12px', color: '#666' }, children: ["Debug: Current coding level: \"", formData.codingLevel, "\" | Button disabled: ", !formData.codingLevel ? 'true' : 'false'] })] }));
            case 4:
                return ((0, jsx_runtime_1.jsxs)("div", { className: "onboarding-step", children: [(0, jsx_runtime_1.jsx)("h2", { children: "Final Step!" }), (0, jsx_runtime_1.jsx)("p", { children: "Just a couple more things to get you coding like a pro (or at least understanding what you're vibecodeing)" }), (0, jsx_runtime_1.jsx)("div", { className: "terms-section", children: (0, jsx_runtime_1.jsxs)("label", { className: "checkbox-label", children: [(0, jsx_runtime_1.jsx)("input", { type: "checkbox", checked: formData.agreedToTerms, onChange: (e) => setFormData({ ...formData, agreedToTerms: e.target.checked }) }), (0, jsx_runtime_1.jsx)("span", { children: "I agree to receive occasional updates." })] }) }), (0, jsx_runtime_1.jsxs)("div", { className: "summary", children: [(0, jsx_runtime_1.jsx)("h3", { children: "Your info:" }), (0, jsx_runtime_1.jsxs)("p", { children: [(0, jsx_runtime_1.jsx)("strong", { children: "Name:" }), " ", formData.name] }), (0, jsx_runtime_1.jsxs)("p", { children: [(0, jsx_runtime_1.jsx)("strong", { children: "Email:" }), " ", formData.email] }), (0, jsx_runtime_1.jsxs)("p", { children: [(0, jsx_runtime_1.jsx)("strong", { children: "Coding Level:" }), " ", formData.codingLevel === 'i-dont-know-what-im-doing' ? 'Honestly confused' : formData.codingLevel] })] }), (0, jsx_runtime_1.jsxs)("div", { className: "button-group", children: [(0, jsx_runtime_1.jsx)("button", { onClick: prevStep, className: "back-btn", children: "\u2190 Back" }), (0, jsx_runtime_1.jsx)("button", { onClick: handleSubmit, className: "complete-btn", disabled: !formData.agreedToTerms, children: "Let's Start" })] })] }));
            default:
                return null;
        }
    };
    return ((0, jsx_runtime_1.jsx)("div", { className: "onboarding-overlay", children: (0, jsx_runtime_1.jsxs)("div", { className: "onboarding-modal", children: [(0, jsx_runtime_1.jsx)("div", { className: "onboarding-content", children: renderStep() }), (0, jsx_runtime_1.jsx)("div", { className: "progress-bar", children: (0, jsx_runtime_1.jsx)("div", { className: "progress-fill", style: { width: `${((currentStep + 1) / 5) * 100}%` } }) })] }) }));
};
exports.default = Onboarding;

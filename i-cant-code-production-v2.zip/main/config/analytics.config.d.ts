export interface AnalyticsConfig {
    enabled: boolean;
    endpoint: string;
    batchSize: number;
    flushInterval: number;
    privacyLevel: 'minimal' | 'standard' | 'detailed';
    collectSystemInfo: boolean;
    collectUsageData: boolean;
    collectErrorData: boolean;
}
export declare const defaultAnalyticsConfig: AnalyticsConfig;
export declare class AnalyticsConfigManager {
    private static instance;
    private config;
    private constructor();
    static getInstance(): AnalyticsConfigManager;
    getConfig(): AnalyticsConfig;
    updateConfig(updates: Partial<AnalyticsConfig>): void;
    isEnabled(): boolean;
    getEndpoint(): string;
    getPrivacyLevel(): string;
    shouldCollectSystemInfo(): boolean;
    shouldCollectUsageData(): boolean;
    shouldCollectErrorData(): boolean;
    private loadConfig;
    private saveConfig;
}
//# sourceMappingURL=analytics.config.d.ts.map
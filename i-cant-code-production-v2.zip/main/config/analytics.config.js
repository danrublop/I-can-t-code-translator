"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalyticsConfigManager = exports.defaultAnalyticsConfig = void 0;
exports.defaultAnalyticsConfig = {
    enabled: true,
    endpoint: 'https://api.icantcode.app/analytics',
    batchSize: 10,
    flushInterval: 30000, // 30 seconds
    privacyLevel: 'standard',
    collectSystemInfo: true,
    collectUsageData: true,
    collectErrorData: true
};
class AnalyticsConfigManager {
    constructor() {
        this.config = { ...exports.defaultAnalyticsConfig };
        this.loadConfig();
    }
    static getInstance() {
        if (!AnalyticsConfigManager.instance) {
            AnalyticsConfigManager.instance = new AnalyticsConfigManager();
        }
        return AnalyticsConfigManager.instance;
    }
    getConfig() {
        return { ...this.config };
    }
    updateConfig(updates) {
        this.config = { ...this.config, ...updates };
        this.saveConfig();
    }
    isEnabled() {
        return this.config.enabled;
    }
    getEndpoint() {
        return this.config.endpoint;
    }
    getPrivacyLevel() {
        return this.config.privacyLevel;
    }
    shouldCollectSystemInfo() {
        return this.config.enabled && this.config.collectSystemInfo;
    }
    shouldCollectUsageData() {
        return this.config.enabled && this.config.collectUsageData;
    }
    shouldCollectErrorData() {
        return this.config.enabled && this.config.collectErrorData;
    }
    loadConfig() {
        try {
            // In a real implementation, you'd load from a config file
            // For now, we'll use the default config
            console.log('Analytics config loaded:', this.config);
        }
        catch (error) {
            console.error('Failed to load analytics config, using defaults:', error);
        }
    }
    saveConfig() {
        try {
            // In a real implementation, you'd save to a config file
            console.log('Analytics config saved:', this.config);
        }
        catch (error) {
            console.error('Failed to save analytics config:', error);
        }
    }
}
exports.AnalyticsConfigManager = AnalyticsConfigManager;
//# sourceMappingURL=analytics.config.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const path_1 = require("path");
const ollama_service_1 = require("./services/ollama.service");
const code_analysis_service_1 = require("./services/code-analysis.service");
const explanation_storage_service_1 = require("./services/explanation-storage.service");
const analytics_service_1 = require("./services/analytics.service");
class MainProcess {
    constructor() {
        this.mainWindow = null;
        this.explanationWindow = null;
        this.isToolbarVisible = true;
        this.clipboardWatcher = null;
        this.lastClipboardContent = '';
        this.ollamaService = new ollama_service_1.OllamaService();
        this.codeAnalysisService = new code_analysis_service_1.CodeAnalysisService();
        this.explanationStorageService = new explanation_storage_service_1.ExplanationStorageService();
    }
    async initialize() {
        // Wait for Electron to be ready
        await electron_1.app.whenReady();
        // Create the main toolbar window
        this.createMainWindow();
        // Register global shortcuts
        this.registerGlobalShortcuts();
        // Set up IPC handlers
        this.setupIpcHandlers();
        // Handle app lifecycle
        this.handleAppLifecycle();
        // Track app launch
        analytics_service_1.analyticsService.trackAppLaunch();
        console.log('i cant code - Initialized successfully');
    }
    checkAndShowOnboarding() {
        // For new users, automatically open the explanation window
        // The explanation window will check localStorage and show onboarding if needed
        console.log('Checking if user needs onboarding...');
        // Automatically open explanation window for new users
        // The explanation window will check localStorage and show onboarding if needed
        setTimeout(() => {
            this.createExplanationWindow();
        }, 1000); // Small delay to ensure main window is fully ready
    }
    createMainWindow() {
        if (this.mainWindow) {
            this.mainWindow.focus();
            return;
        }
        // Get screen dimensions
        const { screen } = require('electron');
        // Calculate toolbar position (center at top) with content-based dimensions
        const toolbarHeight = 40;
        const toolbarY = 50; // Move down from top to avoid menu bar
        this.mainWindow = new electron_1.BrowserWindow({
            width: 700, // Sweet spot - enough space without excess
            height: toolbarHeight,
            x: 0, // Will center after content loads
            y: toolbarY,
            frame: false,
            resizable: true,
            alwaysOnTop: true,
            webPreferences: {
                nodeIntegration: false,
                contextIsolation: true,
                preload: (0, path_1.join)(__dirname, 'preload.js')
            }
        });
        // Fix the path to load from the correct dist directory
        const toolbarPath = (0, path_1.join)(__dirname, '..', 'toolbar.html');
        console.log('Loading toolbar from:', toolbarPath);
        this.mainWindow.loadFile(toolbarPath).catch(error => {
            console.error('Failed to load toolbar:', error);
        });
        // Wait for the window to be ready before sending data
        this.mainWindow.webContents.on('did-finish-load', () => {
            console.log('i cant code - Toolbar loaded and ready');
            // Center the window after content loads
            if (this.mainWindow) {
                const { width: contentWidth } = this.mainWindow.getContentBounds();
                const { width: screenWidth } = screen.getPrimaryDisplay().workAreaSize;
                const toolbarX = Math.round((screenWidth - contentWidth) / 2);
                this.mainWindow.setPosition(toolbarX, toolbarY);
            }
            // Start clipboard monitoring now that the window is ready
            this.startClipboardMonitoring();
            // Send initial clipboard data
            this.updateLineCount(electron_1.clipboard.readText());
            // Check if user needs onboarding and automatically open explanation window
            this.checkAndShowOnboarding();
        });
        this.mainWindow.on('closed', () => {
            this.mainWindow = null;
        });
    }
    registerGlobalShortcuts() {
        // Translation shortcut: Cmd+Shift+T (Mac) / Ctrl+Shift+T (Windows/Linux)
        const translationShortcut = process.platform === 'darwin' ? 'Cmd+Shift+T' : 'Ctrl+Shift+T';
        electron_1.globalShortcut.register(translationShortcut, () => {
            this.handleTranslationShortcut();
        });
        // Toolbar toggle shortcut: Cmd+Shift+H (Mac) / Ctrl+Shift+H (Windows/Linux)
        const toolbarShortcut = process.platform === 'darwin' ? 'Cmd+Shift+H' : 'Ctrl+Shift+H';
        electron_1.globalShortcut.register(toolbarShortcut, () => {
            this.toggleToolbar();
        });
        console.log(`Global shortcuts registered: ${translationShortcut}, ${toolbarShortcut}`);
    }
    async handleTranslationShortcut() {
        let clipboardContent = '';
        let language = '';
        try {
            console.log('Translation shortcut triggered - checking for highlighted text...');
            // Get current clipboard content
            clipboardContent = electron_1.clipboard.readText();
            // If no content, show instructions to the user
            if (!clipboardContent.trim()) {
                console.log('No text in clipboard - showing instructions to user');
                this.showNotification('No text found', 'Please highlight text in any app, copy it (Cmd+C), then press Cmd+Shift+T again');
                return;
            }
            console.log(`Found text in clipboard: ${clipboardContent.substring(0, 100)}...`);
            // Analyze the code
            language = await this.codeAnalysisService.detectLanguage(clipboardContent);
            console.log(`Detected language: ${language}`);
            // Track explanation request
            analytics_service_1.analyticsService.trackExplanationRequest(language, clipboardContent.length);
            // Create explanation window
            this.createExplanationWindow();
            // Send data to explanation window
            this.sendExplanationData({
                code: clipboardContent,
                language: language,
                status: 'processing'
            });
            // Generate AI explanation with progress tracking
            console.log('Starting AI explanation generation...');
            const startTime = Date.now();
            // Send initial progress
            this.sendExplanationData({
                code: clipboardContent,
                language: language,
                explanation: '',
                status: 'processing',
                progress: 0
            });
            // Add timeout wrapper to prevent hanging - increase to 2 minutes for Ollama
            const explanation = await Promise.race([
                this.ollamaService.generateExplanation(clipboardContent, language, 'intermediate', undefined, (progress, partialResponse) => {
                    // Send progress updates to the explanation window
                    this.sendExplanationData({
                        code: clipboardContent,
                        language: language,
                        explanation: partialResponse,
                        status: 'processing',
                        progress: progress
                    });
                }),
                new Promise((_, reject) => setTimeout(() => reject(new Error('AI explanation request timed out after 2 minutes')), 120000))
            ]);
            console.log('AI explanation received, length:', explanation.length);
            // Track explanation completion
            const responseTime = Date.now() - startTime;
            analytics_service_1.analyticsService.trackExplanationCompleted(language, clipboardContent.length, responseTime, true);
            // Ensure the explanation window is still open before sending data
            if (this.explanationWindow && !this.explanationWindow.isDestroyed()) {
                // Send final explanation data
                this.sendExplanationData({
                    code: clipboardContent,
                    language: language,
                    explanation: explanation,
                    status: 'completed',
                    progress: 100
                });
                console.log('Final explanation data sent to window');
                // Auto-save the explanation
                try {
                    await this.explanationStorageService.saveExplanation(clipboardContent, language, explanation);
                    console.log('Explanation auto-saved to notebook');
                }
                catch (error) {
                    console.error('Failed to auto-save explanation:', error);
                }
            }
            else {
                console.log('Explanation window is no longer available');
            }
            console.log('Explanation generated successfully');
        }
        catch (error) {
            console.error('Error handling translation shortcut:', error);
            // Track error
            analytics_service_1.analyticsService.trackError('translation_shortcut', error instanceof Error ? error.message : 'Unknown error occurred', {
                clipboardContent: clipboardContent.substring(0, 100),
                language: language || 'unknown'
            });
            this.sendExplanationData({
                status: 'error',
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            });
        }
    }
    createExplanationWindow() {
        if (this.explanationWindow) {
            this.explanationWindow.focus();
            return;
        }
        // Get screen dimensions
        const { screen } = require('electron');
        const primaryDisplay = screen.getPrimaryDisplay();
        const { width: screenWidth } = primaryDisplay.workAreaSize;
        // Calculate explanation window position (center of screen)
        const explanationWidth = 600;
        const explanationHeight = 700;
        const explanationX = Math.round((screenWidth - explanationWidth) / 2); // Center horizontally
        const explanationY = 150; // Position below toolbar
        this.explanationWindow = new electron_1.BrowserWindow({
            width: explanationWidth,
            height: explanationHeight,
            x: explanationX,
            y: explanationY,
            minWidth: 600,
            minHeight: 400,
            frame: false,
            resizable: true,
            webPreferences: {
                nodeIntegration: false,
                contextIsolation: true,
                preload: (0, path_1.join)(__dirname, 'preload.js')
            }
        });
        // Fix the path to load from the correct dist directory
        const explanationPath = (0, path_1.join)(__dirname, '..', 'explanation.html');
        console.log('Loading explanation window from:', explanationPath);
        this.explanationWindow.loadFile(explanationPath).catch(error => {
            console.error('Failed to load explanation window:', error);
        });
        // Wait for the window to be ready before sending data
        this.explanationWindow.webContents.on('did-finish-load', () => {
            console.log('i cant code - Explanation window loaded and ready');
            // Send initial message to explanation window
            setTimeout(() => {
                console.log('Sending initial message to explanation window');
                this.sendExplanationData({
                    status: 'processing',
                    code: 'Highlight text in any app and press Cmd+Shift+T',
                    language: 'javascript',
                    explanation: '...',
                    progress: 50
                });
            }, 1000);
        });
        this.explanationWindow.on('closed', () => {
            console.log('Explanation window closed');
            this.explanationWindow = null;
        });
    }
    sendExplanationData(data) {
        if (this.explanationWindow && !this.explanationWindow.isDestroyed()) {
            try {
                console.log('Sending data to explanation window:', {
                    status: data.status,
                    hasExplanation: !!data.explanation,
                    explanationLength: data.explanation?.length || 0
                });
                this.explanationWindow.webContents.send('explanation-data', data);
                console.log('Data sent successfully to explanation window');
            }
            catch (error) {
                console.error('Failed to send data to explanation window:', error);
            }
        }
        else {
            console.log('Cannot send data: explanation window is not available');
        }
    }
    toggleToolbar() {
        if (this.mainWindow) {
            if (this.isToolbarVisible) {
                this.mainWindow.hide();
                this.isToolbarVisible = false;
            }
            else {
                this.mainWindow.show();
                this.isToolbarVisible = true;
            }
        }
    }
    setupIpcHandlers() {
        // Handle toolbar visibility toggle
        electron_1.ipcMain.handle('toggle-toolbar', () => {
            this.toggleToolbar();
        });
        // Handle get-toolbar-visibility
        electron_1.ipcMain.handle('get-toolbar-visibility', () => {
            return this.isToolbarVisible;
        });
        // Handle open-settings-page request from toolbar
        electron_1.ipcMain.on('open-settings-page', () => {
            // Ensure explanation window is open
            if (!this.explanationWindow || this.explanationWindow.isDestroyed()) {
                this.createExplanationWindow();
            }
            // Wait a moment for the window to be ready, then send the message
            setTimeout(() => {
                if (this.explanationWindow && !this.explanationWindow.isDestroyed()) {
                    this.explanationWindow.webContents.send('open-settings-page');
                }
            }, 500);
        });
        // Handle open-notebook-in-explanation request from toolbar
        electron_1.ipcMain.on('open-notebook-in-explanation', () => {
            // Ensure explanation window is open
            if (!this.explanationWindow || this.explanationWindow.isDestroyed()) {
                this.createExplanationWindow();
            }
            // Wait a moment for the window to be ready, then send the message
            setTimeout(() => {
                if (this.explanationWindow && !this.explanationWindow.isDestroyed()) {
                    // Send the notebook request
                    this.explanationWindow.webContents.send('open-notebook-in-explanation');
                    // Also send the instruction message for the explanation window
                    this.sendExplanationData({
                        status: 'ready',
                        code: 'Highlight text in any app and press Cmd+Shift+T',
                        language: 'javascript',
                        explanation: '...',
                        progress: 0
                    });
                }
            }, 500);
        });
        // Handle save explanation request
        electron_1.ipcMain.handle('save-explanation', async (_event, data) => {
            try {
                const saved = await this.explanationStorageService.saveExplanation(data.code, data.language, data.explanation, data.title, data.tags);
                return { success: true, explanation: saved };
            }
            catch (error) {
                return {
                    success: false,
                    error: error instanceof Error ? error.message : 'Unknown error'
                };
            }
        });
        // Handle get all explanations request
        electron_1.ipcMain.handle('get-all-explanations', async () => {
            try {
                const explanations = await this.explanationStorageService.loadAllExplanations();
                return { success: true, explanations };
            }
            catch (error) {
                return {
                    success: false,
                    error: error instanceof Error ? error.message : 'Unknown error'
                };
            }
        });
        // Handle search explanations request
        electron_1.ipcMain.handle('search-explanations', async (_event, query) => {
            try {
                const explanations = await this.explanationStorageService.searchExplanations(query);
                return { success: true, explanations };
            }
            catch (error) {
                return {
                    success: false,
                    error: error instanceof Error ? error.message : 'Unknown error'
                };
            }
        });
        // Handle delete explanation request
        electron_1.ipcMain.handle('delete-explanation', async (_event, id) => {
            try {
                const success = await this.explanationStorageService.deleteExplanation(id);
                return { success };
            }
            catch (error) {
                return {
                    success: false,
                    error: error instanceof Error ? error.message : 'Unknown error'
                };
            }
        });
        // Handle window control operations
        electron_1.ipcMain.handle('window-close', () => {
            if (this.explanationWindow && !this.explanationWindow.isDestroyed()) {
                this.explanationWindow.close();
            }
            return { success: true };
        });
        electron_1.ipcMain.handle('window-minimize', () => {
            if (this.explanationWindow && !this.explanationWindow.isDestroyed()) {
                this.explanationWindow.minimize();
            }
            return { success: true };
        });
        electron_1.ipcMain.handle('window-maximize', () => {
            if (this.explanationWindow && !this.explanationWindow.isDestroyed()) {
                if (this.explanationWindow.isMaximized()) {
                    this.explanationWindow.unmaximize();
                }
                else {
                    this.explanationWindow.maximize();
                }
            }
            return { success: true };
        });
        // Handle get all tags request
        electron_1.ipcMain.handle('get-all-tags', async () => {
            try {
                const tags = await this.explanationStorageService.getAllTags();
                return { success: true, tags };
            }
            catch (error) {
                return {
                    success: false,
                    error: error instanceof Error ? error.message : 'Unknown error'
                };
            }
        });
        // Handle get all languages request
        electron_1.ipcMain.handle('get-all-languages', async () => {
            try {
                const languages = await this.explanationStorageService.getAllLanguages();
                return { success: true, languages };
            }
            catch (error) {
                return {
                    success: false,
                    error: error instanceof Error ? error.message : 'Unknown error'
                };
            }
        });
        // Handle export explanations request
        electron_1.ipcMain.handle('export-explanations', async (_event, format) => {
            try {
                const data = await this.explanationStorageService.exportExplanations(format);
                return { success: true, data };
            }
            catch (error) {
                return {
                    success: false,
                    error: error instanceof Error ? error.message : 'Unknown error'
                };
            }
        });
    }
    startClipboardMonitoring() {
        // Check clipboard every 500ms for changes
        this.clipboardWatcher = setInterval(() => {
            const currentContent = electron_1.clipboard.readText();
            // Only process if content has changed
            if (currentContent !== this.lastClipboardContent) {
                this.lastClipboardContent = currentContent;
                this.updateLineCount(currentContent);
            }
        }, 500);
    }
    updateLineCount(content) {
        if (!this.mainWindow || this.mainWindow.isDestroyed())
            return;
        const lineCount = content.trim() ? content.split('\n').length : 0;
        const charCount = content.length;
        // Send line count update to toolbar
        this.mainWindow.webContents.send('clipboard-update', {
            lineCount,
            charCount,
            hasContent: content.trim().length > 0
        });
    }
    stopClipboardMonitoring() {
        if (this.clipboardWatcher) {
            clearInterval(this.clipboardWatcher);
            this.clipboardWatcher = null;
        }
    }
    handleAppLifecycle() {
        electron_1.app.on('window-all-closed', () => {
            if (process.platform !== 'darwin') {
                electron_1.app.quit();
            }
        });
        electron_1.app.on('activate', () => {
            if (electron_1.BrowserWindow.getAllWindows().length === 0) {
                this.createMainWindow();
            }
        });
        electron_1.app.on('before-quit', () => {
            this.stopClipboardMonitoring();
        });
    }
    showNotification(title, message) {
        // Create a simple notification window
        const notificationWindow = new electron_1.BrowserWindow({
            width: 400,
            height: 120,
            frame: false,
            alwaysOnTop: true,
            skipTaskbar: true,
            webPreferences: {
                nodeIntegration: false,
                contextIsolation: true
            }
        });
        notificationWindow.loadURL(`data:text/html,
      <html>
        <head>
          <style>
            body { 
              margin: 0; 
              padding: 20px; 
              background: #2a2a2a; 
              color: #ffffff; 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              border-radius: 8px;
              display: flex;
              flex-direction: column;
              justify-content: center;
              align-items: center;
              text-align: center;
            }
            .title { 
              font-weight: bold; 
              margin-bottom: 12px; 
              font-size: 16px;
              color: #3b82f6;
            }
            .message { 
              color: #e5e7eb; 
              font-size: 14px;
              line-height: 1.4;
            }
            .shortcut {
              background: #374151;
              padding: 4px 8px;
              border-radius: 4px;
              font-family: monospace;
              margin: 0 4px;
            }
          </style>
        </head>
        <body>
          <div class="title">${title}</div>
          <div class="message">${message}</div>
        </body>
      </html>
    `);
        // Auto-close after 5 seconds
        setTimeout(() => {
            if (!notificationWindow.isDestroyed()) {
                notificationWindow.close();
            }
        }, 5000);
    }
}
// Initialize the application
const mainProcess = new MainProcess();
mainProcess.initialize().catch(console.error);
//# sourceMappingURL=main.js.map
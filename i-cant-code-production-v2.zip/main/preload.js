"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
electron_1.contextBridge.exposeInMainWorld('electronAPI', {
    // Context file operations
    addContextFile: (filePath) => electron_1.ipcRenderer.invoke('add-context-file', filePath),
    // Translation operations
    translateCode: (code, detailLevel) => electron_1.ipcRenderer.invoke('translate-code', code, detailLevel),
    // Clipboard operations
    getClipboardLineCount: () => electron_1.ipcRenderer.invoke('get-clipboard-line-count'),
    // Event listeners
    onExplanationData: (callback) => {
        electron_1.ipcRenderer.on('explanation-data', (_event, data) => callback(data));
    },
    onClipboardUpdate: (callback) => {
        electron_1.ipcRenderer.on('clipboard-update', (_event, data) => callback(data));
    },
    onOpenSettingsPage: (callback) => {
        electron_1.ipcRenderer.on('open-settings-page', () => callback());
    },
    onOpenNotebookInExplanation: (callback) => {
        electron_1.ipcRenderer.on('open-notebook-in-explanation', () => callback());
    },
    // Settings page control
    openSettingsPage: () => {
        // Send IPC message to main process to open settings page
        electron_1.ipcRenderer.send('open-settings-page');
    },
    // Notebook operations
    openNotebookInExplanation: () => {
        electron_1.ipcRenderer.send('open-notebook-in-explanation');
    },
    saveExplanation: (data) => electron_1.ipcRenderer.invoke('save-explanation', data),
    getAllExplanations: () => electron_1.ipcRenderer.invoke('get-all-explanations'),
    searchExplanations: (query) => electron_1.ipcRenderer.invoke('search-explanations', query),
    deleteExplanation: (id) => electron_1.ipcRenderer.invoke('delete-explanation', id),
    getAllTags: () => electron_1.ipcRenderer.invoke('get-all-tags'),
    getAllLanguages: () => electron_1.ipcRenderer.invoke('get-all-languages'),
    exportExplanations: (format) => electron_1.ipcRenderer.invoke('export-explanations', format),
    // Remove event listeners
    removeExplanationDataListener: () => {
        electron_1.ipcRenderer.removeAllListeners('explanation-data');
    },
    removeClipboardUpdateListener: () => {
        electron_1.ipcRenderer.removeAllListeners('clipboard-update');
    },
    removeOpenSettingsPageListener: () => {
        electron_1.ipcRenderer.removeAllListeners('open-settings-page');
    },
    // Window control operations
    windowClose: () => electron_1.ipcRenderer.invoke('window-close'),
    windowMinimize: () => electron_1.ipcRenderer.invoke('window-minimize'),
    windowMaximize: () => electron_1.ipcRenderer.invoke('window-maximize')
});
//# sourceMappingURL=preload.js.map
export interface AnalyticsEvent {
    eventType: 'app_launched' | 'explanation_requested' | 'explanation_completed' | 'error_occurred';
    timestamp: string;
    sessionId: string;
    data: any;
    systemInfo: {
        platform: string;
        arch: string;
        nodeVersion: string;
        electronVersion: string;
        appVersion: string;
    };
}
export interface UserMetrics {
    totalExplanations: number;
    totalErrors: number;
    averageResponseTime: number;
    favoriteLanguages: string[];
    lastActive: string;
}
declare class AnalyticsService {
    private sessionId;
    private isOnline;
    private pendingEvents;
    private configManager;
    constructor();
    /**
     * Generate a unique session ID
     */
    private generateSessionId;
    /**
     * Get system information
     */
    private getSystemInfo;
    /**
     * Track app launch
     */
    trackAppLaunch(): void;
    /**
     * Track explanation request
     */
    trackExplanationRequest(language: string, codeLength: number): void;
    /**
     * Track explanation completion
     */
    trackExplanationCompleted(language: string, codeLength: number, responseTime: number, success: boolean): void;
    /**
     * Track error occurrence
     */
    trackError(errorType: string, errorMessage: string, context?: any): void;
    /**
     * Send analytics event to server
     */
    private sendEvent;
    /**
     * Update local metrics
     */
    private updateMetrics;
    /**
     * Load metrics from file
     */
    private loadMetrics;
    /**
     * Save metrics to file
     */
    private saveMetrics;
    /**
     * Get current metrics
     */
    getMetrics(): UserMetrics;
    /**
     * Flush pending events (when back online)
     */
    flushPendingEvents(): Promise<void>;
    /**
     * Set online status
     */
    setOnlineStatus(online: boolean): void;
}
export declare const analyticsService: AnalyticsService;
export {};
//# sourceMappingURL=analytics.service.d.ts.map
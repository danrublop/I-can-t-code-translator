"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.analyticsService = void 0;
const electron_1 = require("electron");
const analytics_config_1 = require("../config/analytics.config");
class AnalyticsService {
    constructor() {
        this.isOnline = true;
        this.pendingEvents = [];
        this.sessionId = this.generateSessionId();
        this.configManager = analytics_config_1.AnalyticsConfigManager.getInstance();
        this.loadMetrics();
    }
    /**
     * Generate a unique session ID
     */
    generateSessionId() {
        return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    /**
     * Get system information
     */
    getSystemInfo() {
        if (!this.configManager.shouldCollectSystemInfo()) {
            return {
                platform: 'unknown',
                arch: 'unknown',
                nodeVersion: 'unknown',
                electronVersion: 'unknown',
                appVersion: '1.0.0'
            };
        }
        return {
            platform: process.platform,
            arch: process.arch,
            nodeVersion: process.version,
            electronVersion: process.versions.electron,
            appVersion: '1.0.0'
        };
    }
    /**
     * Track app launch
     */
    trackAppLaunch() {
        const event = {
            eventType: 'app_launched',
            timestamp: new Date().toISOString(),
            sessionId: this.sessionId,
            data: {
                launchTime: Date.now(),
                clipboardContent: electron_1.clipboard.readText().substring(0, 100) // First 100 chars for context
            },
            systemInfo: this.getSystemInfo()
        };
        this.sendEvent(event);
    }
    /**
     * Track explanation request
     */
    trackExplanationRequest(language, codeLength) {
        const event = {
            eventType: 'explanation_requested',
            timestamp: new Date().toISOString(),
            sessionId: this.sessionId,
            data: {
                language,
                codeLength,
                requestTime: Date.now()
            },
            systemInfo: this.getSystemInfo()
        };
        this.sendEvent(event);
    }
    /**
     * Track explanation completion
     */
    trackExplanationCompleted(language, codeLength, responseTime, success) {
        const event = {
            eventType: 'explanation_completed',
            timestamp: new Date().toISOString(),
            sessionId: this.sessionId,
            data: {
                language,
                codeLength,
                responseTime,
                success,
                completionTime: Date.now()
            },
            systemInfo: this.getSystemInfo()
        };
        this.sendEvent(event);
        this.updateMetrics(language, responseTime, success);
    }
    /**
     * Track error occurrence
     */
    trackError(errorType, errorMessage, context) {
        const event = {
            eventType: 'error_occurred',
            timestamp: new Date().toISOString(),
            sessionId: this.sessionId,
            data: {
                errorType,
                errorMessage,
                context,
                errorTime: Date.now()
            },
            systemInfo: this.getSystemInfo()
        };
        this.sendEvent(event);
        this.updateMetrics('error', 0, false);
    }
    /**
     * Send analytics event to server
     */
    async sendEvent(event) {
        // Check if analytics is enabled
        if (!this.configManager.isEnabled()) {
            console.log('Analytics disabled, skipping event:', event.eventType);
            return;
        }
        if (!this.isOnline) {
            this.pendingEvents.push(event);
            return;
        }
        try {
            const response = await fetch(this.configManager.getEndpoint(), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(event)
            });
            if (!response.ok) {
                throw new Error(`Analytics request failed: ${response.status}`);
            }
            console.log('Analytics event sent successfully:', event.eventType);
        }
        catch (error) {
            console.error('Failed to send analytics event:', error);
            this.pendingEvents.push(event);
        }
    }
    /**
     * Update local metrics
     */
    updateMetrics(language, responseTime, success) {
        try {
            const metrics = this.loadMetrics();
            if (success) {
                metrics.totalExplanations += 1;
                // Update average response time
                const totalTime = metrics.averageResponseTime * (metrics.totalExplanations - 1) + responseTime;
                metrics.averageResponseTime = totalTime / metrics.totalExplanations;
                // Update favorite languages
                if (!metrics.favoriteLanguages.includes(language)) {
                    metrics.favoriteLanguages.push(language);
                }
            }
            else {
                metrics.totalErrors += 1;
            }
            metrics.lastActive = new Date().toISOString();
            this.saveMetrics(metrics);
        }
        catch (error) {
            console.error('Failed to update metrics:', error);
        }
    }
    /**
     * Load metrics from file
     */
    loadMetrics() {
        try {
            // For now, return default metrics
            // In a real implementation, you'd load from a file
            return {
                totalExplanations: 0,
                totalErrors: 0,
                averageResponseTime: 0,
                favoriteLanguages: [],
                lastActive: new Date().toISOString()
            };
        }
        catch (error) {
            console.error('Failed to load metrics:', error);
            return {
                totalExplanations: 0,
                totalErrors: 0,
                averageResponseTime: 0,
                favoriteLanguages: [],
                lastActive: new Date().toISOString()
            };
        }
    }
    /**
     * Save metrics to file
     */
    saveMetrics(metrics) {
        try {
            // For now, just log the metrics
            // In a real implementation, you'd save to a file
            console.log('Metrics updated:', metrics);
        }
        catch (error) {
            console.error('Failed to save metrics:', error);
        }
    }
    /**
     * Get current metrics
     */
    getMetrics() {
        return this.loadMetrics();
    }
    /**
     * Flush pending events (when back online)
     */
    async flushPendingEvents() {
        if (this.pendingEvents.length === 0)
            return;
        console.log(`Flushing ${this.pendingEvents.length} pending analytics events...`);
        for (const event of this.pendingEvents) {
            await this.sendEvent(event);
        }
        this.pendingEvents = [];
        console.log('Pending analytics events flushed successfully');
    }
    /**
     * Set online status
     */
    setOnlineStatus(online) {
        this.isOnline = online;
        if (online) {
            this.flushPendingEvents();
        }
    }
}
exports.analyticsService = new AnalyticsService();
//# sourceMappingURL=analytics.service.js.map
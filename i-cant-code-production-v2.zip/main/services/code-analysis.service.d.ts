export interface LanguageDetectionResult {
    language: string;
    confidence: number;
    extensions: string[];
    keywords: string[];
}
export declare class CodeAnalysisService {
    private readonly languagePatterns;
    constructor();
    detectLanguage(code: string): Promise<string>;
    analyzeCode(code: string): Promise<LanguageDetectionResult>;
    private initializeLanguagePatterns;
    private matchesShebang;
    private analyzeSyntaxStructure;
}
//# sourceMappingURL=code-analysis.service.d.ts.map
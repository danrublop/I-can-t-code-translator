export interface SavedExplanation {
    id: string;
    timestamp: number;
    code: string;
    language: string;
    explanation: string;
    title?: string;
    tags?: string[];
}
export declare class ExplanationStorageService {
    private readonly storageDir;
    private readonly storageFile;
    constructor();
    private ensureStorageDirectory;
    saveExplanation(code: string, language: string, explanation: string, title?: string, tags?: string[]): Promise<SavedExplanation>;
    loadAllExplanations(): Promise<SavedExplanation[]>;
    getExplanationById(id: string): Promise<SavedExplanation | null>;
    deleteExplanation(id: string): Promise<boolean>;
    updateExplanation(id: string, updates: Partial<Omit<SavedExplanation, 'id' | 'timestamp'>>): Promise<SavedExplanation | null>;
    searchExplanations(query: string): Promise<SavedExplanation[]>;
    getExplanationsByLanguage(language: string): Promise<SavedExplanation[]>;
    getExplanationsByTag(tag: string): Promise<SavedExplanation[]>;
    getAllTags(): Promise<string[]>;
    getAllLanguages(): Promise<string[]>;
    private saveToFile;
    private generateId;
    private generateTitle;
    exportExplanations(format?: 'json' | 'markdown'): Promise<string>;
    private generateMarkdownExport;
    importExplanations(jsonData: string): Promise<number>;
}
//# sourceMappingURL=explanation-storage.service.d.ts.map
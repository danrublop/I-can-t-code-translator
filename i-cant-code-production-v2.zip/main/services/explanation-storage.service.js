"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExplanationStorageService = void 0;
const electron_1 = require("electron");
const path_1 = require("path");
const fs_1 = require("fs");
class ExplanationStorageService {
    constructor() {
        this.storageDir = (0, path_1.join)(electron_1.app.getPath('userData'), 'explanations');
        this.storageFile = (0, path_1.join)(this.storageDir, 'saved-explanations.json');
        this.ensureStorageDirectory();
    }
    async ensureStorageDirectory() {
        try {
            await fs_1.promises.access(this.storageDir);
        }
        catch {
            await fs_1.promises.mkdir(this.storageDir, { recursive: true });
        }
    }
    async saveExplanation(code, language, explanation, title, tags) {
        const savedExplanation = {
            id: this.generateId(),
            timestamp: Date.now(),
            code,
            language,
            explanation,
            title: title || this.generateTitle(code),
            tags: tags || []
        };
        const existingExplanations = await this.loadAllExplanations();
        existingExplanations.push(savedExplanation);
        await this.saveToFile(existingExplanations);
        return savedExplanation;
    }
    async loadAllExplanations() {
        try {
            const data = await fs_1.promises.readFile(this.storageFile, 'utf-8');
            return JSON.parse(data);
        }
        catch {
            return [];
        }
    }
    async getExplanationById(id) {
        const explanations = await this.loadAllExplanations();
        return explanations.find(exp => exp.id === id) || null;
    }
    async deleteExplanation(id) {
        const explanations = await this.loadAllExplanations();
        const filteredExplanations = explanations.filter(exp => exp.id !== id);
        if (filteredExplanations.length < explanations.length) {
            await this.saveToFile(filteredExplanations);
            return true;
        }
        return false;
    }
    async updateExplanation(id, updates) {
        const explanations = await this.loadAllExplanations();
        const index = explanations.findIndex(exp => exp.id === id);
        if (index === -1)
            return null;
        explanations[index] = { ...explanations[index], ...updates };
        await this.saveToFile(explanations);
        return explanations[index];
    }
    async searchExplanations(query) {
        const explanations = await this.loadAllExplanations();
        const lowerQuery = query.toLowerCase();
        return explanations.filter(exp => exp.title?.toLowerCase().includes(lowerQuery) ||
            exp.code.toLowerCase().includes(lowerQuery) ||
            exp.explanation.toLowerCase().includes(lowerQuery) ||
            exp.language.toLowerCase().includes(lowerQuery) ||
            (exp.tags && exp.tags.some(tag => tag.toLowerCase().includes(lowerQuery))));
    }
    async getExplanationsByLanguage(language) {
        const explanations = await this.loadAllExplanations();
        return explanations.filter(exp => exp.language.toLowerCase() === language.toLowerCase());
    }
    async getExplanationsByTag(tag) {
        const explanations = await this.loadAllExplanations();
        return explanations.filter(exp => exp.tags && exp.tags.some(t => t.toLowerCase() === tag.toLowerCase()));
    }
    async getAllTags() {
        const explanations = await this.loadAllExplanations();
        const tagSet = new Set();
        explanations.forEach(exp => {
            if (exp.tags) {
                exp.tags.forEach(tag => tagSet.add(tag));
            }
        });
        return Array.from(tagSet).sort();
    }
    async getAllLanguages() {
        const explanations = await this.loadAllExplanations();
        const languageSet = new Set();
        explanations.forEach(exp => {
            languageSet.add(exp.language);
        });
        return Array.from(languageSet).sort();
    }
    async saveToFile(explanations) {
        await fs_1.promises.writeFile(this.storageFile, JSON.stringify(explanations, null, 2), 'utf-8');
    }
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
    generateTitle(code) {
        const firstLine = code.split('\n')[0].trim();
        if (firstLine.length > 50) {
            return firstLine.substring(0, 47) + '...';
        }
        return firstLine || 'Untitled Explanation';
    }
    async exportExplanations(format = 'json') {
        const explanations = await this.loadAllExplanations();
        if (format === 'json') {
            return JSON.stringify(explanations, null, 2);
        }
        else {
            return this.generateMarkdownExport(explanations);
        }
    }
    generateMarkdownExport(explanations) {
        let markdown = '# Saved Code Explanations\n\n';
        explanations.forEach((exp, index) => {
            markdown += `## ${index + 1}. ${exp.title}\n\n`;
            markdown += `**Language:** ${exp.language}\n\n`;
            markdown += `**Date:** ${new Date(exp.timestamp).toLocaleString()}\n\n`;
            if (exp.tags && exp.tags.length > 0) {
                markdown += `**Tags:** ${exp.tags.join(', ')}\n\n`;
            }
            markdown += `**Code:**\n\`\`\`${exp.language}\n${exp.code}\n\`\`\`\n\n`;
            markdown += `**Explanation:**\n\n${exp.explanation}\n\n`;
            markdown += '---\n\n';
        });
        return markdown;
    }
    async importExplanations(jsonData) {
        try {
            const explanations = JSON.parse(jsonData);
            if (!Array.isArray(explanations)) {
                throw new Error('Invalid data format');
            }
            const existingExplanations = await this.loadAllExplanations();
            const newExplanations = explanations.filter((exp) => exp.code && exp.language && exp.explanation);
            const allExplanations = [...existingExplanations, ...newExplanations];
            await this.saveToFile(allExplanations);
            return newExplanations.length;
        }
        catch (error) {
            throw new Error(`Failed to import explanations: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
}
exports.ExplanationStorageService = ExplanationStorageService;
//# sourceMappingURL=explanation-storage.service.js.map
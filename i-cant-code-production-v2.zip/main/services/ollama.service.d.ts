export interface OllamaResponse {
    model: string;
    created_at: string;
    response: string;
    done: boolean;
    context: number[];
    total_duration: number;
    load_duration: number;
    prompt_eval_duration: number;
    eval_duration: number;
}
export interface ExplanationRequest {
    code: string;
    language: string;
    detailLevel?: 'beginner' | 'intermediate' | 'expert';
    contextFiles?: string[];
}
export declare class OllamaService {
    private readonly baseUrl;
    private readonly model;
    private readonly timeout;
    constructor();
    private testConnection;
    generateExplanation(code: string, language: string, detailLevel?: 'beginner' | 'intermediate' | 'expert', contextFiles?: string[], onProgress?: (progress: number, partialResponse: string) => void): Promise<string>;
    private generateExplanationStream;
    private buildPrompt;
    private getDetailLevelInstructions;
    private cleanResponse;
    isModelAvailable(): Promise<boolean>;
    pullModel(): Promise<void>;
}
//# sourceMappingURL=ollama.service.d.ts.map
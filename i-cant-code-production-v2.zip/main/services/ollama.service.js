"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OllamaService = void 0;
const axios_1 = __importDefault(require("axios"));
class OllamaService {
    constructor() {
        this.baseUrl = 'http://127.0.0.1:11434';
        this.model = 'mistral:latest';
        this.timeout = 300000; // Increased to 5 minutes for very slow responses
        // Test connection on initialization
        this.testConnection();
    }
    async testConnection() {
        try {
            await axios_1.default.get(`${this.baseUrl}/api/tags`, { timeout: 5000 });
            console.log('Ollama connection successful');
        }
        catch (error) {
            console.warn('Ollama connection failed. Make sure Ollama is running and accessible at http://127.0.0.1:11434');
        }
    }
    async generateExplanation(code, language, detailLevel = 'intermediate', contextFiles, onProgress) {
        try {
            const prompt = this.buildPrompt(code, language, detailLevel, contextFiles);
            console.log('Generating explanation using streaming method for real-time progress...');
            // Use streaming for real-time progress updates
            const result = await this.generateExplanationStream(prompt, onProgress);
            return result;
        }
        catch (error) {
            if (axios_1.default.isAxiosError(error)) {
                if (error.code === 'ECONNREFUSED') {
                    throw new Error('Ollama is not running. Please start Ollama and ensure it\'s accessible at http://127.0.0.1:11434');
                }
                if (error.code === 'ETIMEDOUT') {
                    throw new Error('Request to Ollama timed out. The model may be taking too long to respond.');
                }
                throw new Error(`Ollama API error: ${error.message}`);
            }
            throw new Error(`Failed to generate explanation: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    async generateExplanationStream(prompt, onProgress) {
        console.log('Starting streaming request to Ollama...');
        let fullResponse = '';
        let tokenCount = 0;
        let estimatedTotalTokens = 1000; // Estimate for progress calculation
        try {
            const response = await axios_1.default.post(`${this.baseUrl}/api/generate`, {
                model: this.model,
                prompt: prompt,
                stream: true,
                options: {
                    temperature: 0.7,
                    top_p: 0.9,
                    max_tokens: 2000
                }
            }, {
                timeout: this.timeout,
                responseType: 'stream'
            });
            // Process the streaming response
            return new Promise((resolve, reject) => {
                let buffer = '';
                response.data.on('data', (chunk) => {
                    buffer += chunk.toString();
                    // Process complete lines from the buffer
                    const lines = buffer.split('\n');
                    buffer = lines.pop() || ''; // Keep incomplete line in buffer
                    for (const line of lines) {
                        if (line.trim() === '')
                            continue;
                        try {
                            const data = JSON.parse(line);
                            if (data.response) {
                                fullResponse += data.response;
                                tokenCount++;
                                // Calculate progress based on token count
                                const progress = Math.min(Math.round((tokenCount / estimatedTotalTokens) * 100), 95);
                                if (onProgress) {
                                    onProgress(progress, fullResponse);
                                }
                            }
                            if (data.done) {
                                estimatedTotalTokens = tokenCount;
                                if (onProgress) {
                                    onProgress(100, fullResponse);
                                }
                                resolve(this.cleanResponse(fullResponse));
                            }
                        }
                        catch (parseError) {
                            // Skip malformed JSON lines
                            continue;
                        }
                    }
                });
                response.data.on('end', () => {
                    if (fullResponse) {
                        if (onProgress) {
                            onProgress(100, fullResponse);
                        }
                        resolve(this.cleanResponse(fullResponse));
                    }
                    else {
                        reject(new Error('No response received from Ollama'));
                    }
                });
                response.data.on('error', (error) => {
                    reject(new Error(`Stream error: ${error.message}`));
                });
            });
        }
        catch (error) {
            console.error('Streaming request failed:', error);
            if (axios_1.default.isAxiosError(error)) {
                if (error.code === 'ECONNREFUSED') {
                    throw new Error('Ollama connection refused. Please check if Ollama is running.');
                }
                if (error.code === 'ETIMEDOUT') {
                    throw new Error('Ollama request timed out. The model may be taking too long to respond.');
                }
                throw new Error(`Ollama API error: ${error.message}`);
            }
            throw error;
        }
    }
    buildPrompt(code, language, detailLevel, contextFiles) {
        const detailInstructions = this.getDetailLevelInstructions(detailLevel);
        let prompt = `You are an expert programming tutor. Please explain the following ${language} code at a ${detailLevel} level.

${detailInstructions}

Code to explain:
\`\`\`${language}
${code}
\`\`\`

`;
        if (contextFiles && contextFiles.length > 0) {
            prompt += `Additional context files that may be relevant:
${contextFiles.map(file => `- ${file}`).join('\n')}

`;
        }
        prompt += `Please provide a clear, structured explanation that includes:

1. **Overview**: A brief summary of what this code does
2. **Line-by-line breakdown**: Explain key parts of the code
3. **Key concepts**: Highlight important programming concepts used
4. **Potential improvements**: Suggest ways to make the code better (if applicable)
5. **Common pitfalls**: Point out potential issues or things to watch out for

Format your response in markdown with clear headings and code examples where helpful.`;
        return prompt;
    }
    getDetailLevelInstructions(level) {
        switch (level) {
            case 'beginner':
                return 'Use simple language and explain basic programming concepts. Assume the reader is new to programming.';
            case 'intermediate':
                return 'Use moderate technical language and explain intermediate concepts. Assume the reader has basic programming knowledge.';
            case 'expert':
                return 'Use advanced technical language and explain complex concepts. Assume the reader is an experienced programmer.';
            default:
                return 'Use moderate technical language and explain intermediate concepts.';
        }
    }
    cleanResponse(response) {
        // Remove any markdown code block markers that might be in the response
        return response
            .replace(/^```\w*\n/, '') // Remove opening code block
            .replace(/\n```$/, '') // Remove closing code block
            .trim();
    }
    async isModelAvailable() {
        try {
            const response = await axios_1.default.get(`${this.baseUrl}/api/tags`, { timeout: 5000 });
            const models = response.data.models || [];
            return models.some((model) => model.name === this.model);
        }
        catch (error) {
            return false;
        }
    }
    async pullModel() {
        try {
            await axios_1.default.post(`${this.baseUrl}/api/pull`, {
                name: this.model
            }, { timeout: 300000 }); // 5 minutes for model download
            console.log(`Model ${this.model} pulled successfully`);
        }
        catch (error) {
            throw new Error(`Failed to pull model ${this.model}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
}
exports.OllamaService = OllamaService;
//# sourceMappingURL=ollama.service.js.map
"use strict";
// Notebook functionality for Code Translator
class Notebook {
    constructor() {
        this.explanations = [];
        this.filteredExplanations = [];
        this.selectedExplanation = null;
        this.activeFilters = {
            languages: new Set(),
            tags: new Set()
        };
        this.init();
    }
    async init() {
        this.setupEventListeners();
        this.setupWindowControls();
        await this.loadExplanations();
        this.renderExplanations();
        this.renderFilters();
    }
    setupEventListeners() {
        // Search functionality
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.handleSearch(e.target.value);
            });
        }
        // Explanation list clicks
        const explanationList = document.getElementById('explanation-list');
        if (explanationList) {
            explanationList.addEventListener('click', (e) => {
                const item = e.target.closest('.explanation-item');
                if (item) {
                    const id = item.dataset.id;
                    this.selectExplanation(id);
                }
            });
        }
    }
    setupWindowControls() {
        const closeBtn = document.getElementById('close-btn');
        const minimizeBtn = document.getElementById('minimize-btn');
        const maximizeBtn = document.getElementById('maximize-btn');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                window.close();
            });
        }
        if (minimizeBtn) {
            minimizeBtn.addEventListener('click', () => {
                // Minimize functionality
            });
        }
        if (maximizeBtn) {
            maximizeBtn.addEventListener('click', () => {
                // Maximize functionality
            });
        }
    }
    async loadExplanations() {
        try {
            if (window.electronAPI) {
                const result = await window.electronAPI.getAllExplanations();
                if (result.success) {
                    this.explanations = result.explanations || [];
                    this.filteredExplanations = [...this.explanations];
                }
                else {
                    console.error('Failed to load explanations:', result.error);
                }
            }
            else {
                // Fallback for testing
                this.explanations = this.getMockData();
                this.filteredExplanations = [...this.explanations];
            }
        }
        catch (error) {
            console.error('Error loading explanations:', error);
            // Fallback for testing
            this.explanations = this.getMockData();
            this.filteredExplanations = [...this.explanations];
        }
    }
    getMockData() {
        return [
            {
                id: '1',
                timestamp: Date.now() - 86400000, // 1 day ago
                code: 'function hello() {\n  console.log("Hello, World!");\n}',
                language: 'javascript',
                explanation: 'This is a simple JavaScript function that prints "Hello, World!" to the console.',
                title: 'Hello World Function',
                tags: ['javascript', 'function', 'console']
            },
            {
                id: '2',
                timestamp: Date.now() - 172800000, // 2 days ago
                code: 'def greet(name):\n    return f"Hello, {name}!"',
                language: 'python',
                explanation: 'A Python function that takes a name parameter and returns a greeting string using f-string formatting.',
                title: 'Python Greeting Function',
                tags: ['python', 'function', 'string']
            }
        ];
    }
    handleSearch(query) {
        if (!query.trim()) {
            this.filteredExplanations = [...this.explanations];
        }
        else {
            this.filteredExplanations = this.explanations.filter(exp => exp.title?.toLowerCase().includes(query.toLowerCase()) ||
                exp.code.toLowerCase().includes(query.toLowerCase()) ||
                exp.explanation.toLowerCase().includes(query.toLowerCase()) ||
                exp.language.toLowerCase().includes(query.toLowerCase()) ||
                exp.tags.some(tag => tag.toLowerCase().includes(query.toLowerCase())));
        }
        this.applyFilters();
        this.renderExplanations();
    }
    applyFilters() {
        let filtered = [...this.filteredExplanations];
        // Apply language filters
        if (this.activeFilters.languages.size > 0) {
            filtered = filtered.filter(exp => this.activeFilters.languages.has(exp.language));
        }
        // Apply tag filters
        if (this.activeFilters.tags.size > 0) {
            filtered = filtered.filter(exp => exp.tags.some(tag => this.activeFilters.tags.has(tag)));
        }
        this.filteredExplanations = filtered;
    }
    toggleFilter(type, value) {
        if (type === 'language') {
            if (this.activeFilters.languages.has(value)) {
                this.activeFilters.languages.delete(value);
            }
            else {
                this.activeFilters.languages.add(value);
            }
        }
        else if (type === 'tag') {
            if (this.activeFilters.tags.has(value)) {
                this.activeFilters.tags.delete(value);
            }
            else {
                this.activeFilters.tags.add(value);
            }
        }
        this.applyFilters();
        this.renderExplanations();
        this.renderFilters();
    }
    renderFilters() {
        // Render language filters
        const languageFilters = document.getElementById('language-filters');
        if (languageFilters) {
            const languages = [...new Set(this.explanations.map(exp => exp.language))];
            languageFilters.innerHTML = languages.map(lang => `
                <span class="filter-tag ${this.activeFilters.languages.has(lang) ? 'active' : ''}" 
                      onclick="notebook.toggleFilter('language', '${lang}')">
                    ${lang}
                </span>
            `).join('');
        }
        // Render tag filters
        const tagFilters = document.getElementById('tag-filters');
        if (tagFilters) {
            const tags = [...new Set(this.explanations.flatMap(exp => exp.tags))];
            tagFilters.innerHTML = tags.map(tag => `
                <span class="filter-tag ${this.activeFilters.tags.has(tag) ? 'active' : ''}" 
                      onclick="notebook.toggleFilter('tag', '${tag}')">
                    ${tag}
                </span>
            `).join('');
        }
    }
    renderExplanations() {
        const explanationList = document.getElementById('explanation-list');
        if (!explanationList)
            return;
        if (this.filteredExplanations.length === 0) {
            explanationList.innerHTML = `
                <div style="padding: 20px; text-align: center; color: #9ca3af;">
                    No explanations found matching your criteria.
                </div>
            `;
            return;
        }
        explanationList.innerHTML = this.filteredExplanations.map(exp => `
            <div class="explanation-item ${this.selectedExplanation?.id === exp.id ? 'selected' : ''}" 
                 data-id="${exp.id}">
                <div class="explanation-title">${exp.title || 'Untitled'}</div>
                <div class="explanation-meta">
                    <span>${exp.language}</span>
                    <span>${new Date(exp.timestamp).toLocaleDateString()}</span>
                    <span>${exp.tags.join(', ')}</span>
                </div>
                <div class="explanation-preview">${exp.explanation.substring(0, 100)}...</div>
            </div>
        `).join('');
    }
    selectExplanation(id) {
        this.selectedExplanation = this.explanations.find(exp => exp.id === id);
        this.renderExplanations();
        this.renderExplanationDetail();
    }
    renderExplanationDetail() {
        const contentHeader = document.getElementById('content-header');
        const contentBody = document.getElementById('content-body');
        const emptyState = document.getElementById('empty-state');
        if (!this.selectedExplanation) {
            if (contentHeader)
                contentHeader.style.display = 'none';
            if (emptyState)
                emptyState.style.display = 'block';
            return;
        }
        const exp = this.selectedExplanation;
        // Show content header
        if (contentHeader) {
            contentHeader.style.display = 'block';
            document.getElementById('explanation-title').textContent = exp.title || 'Untitled';
            document.getElementById('explanation-language').textContent = exp.language;
            document.getElementById('explanation-date').textContent = new Date(exp.timestamp).toLocaleString();
            document.getElementById('explanation-tags').textContent = exp.tags.join(', ');
        }
        // Hide empty state
        if (emptyState) {
            emptyState.style.display = 'none';
        }
        // Render content body
        if (contentBody) {
            contentBody.innerHTML = `
                <div class="code-section">
                    <h3>Code</h3>
                    <div class="code-block">
                        <pre><code>${this.escapeHtml(exp.code)}</code></pre>
                    </div>
                </div>
                
                <div class="explanation-section">
                    <h3>Explanation</h3>
                    <div class="explanation-content">
                        ${this.formatExplanation(exp.explanation)}
                    </div>
                </div>
                
                <div style="margin-top: 24px;">
                    <button class="btn btn-danger" onclick="notebook.deleteExplanation('${exp.id}')">
                        Delete Explanation
                    </button>
                </div>
            `;
        }
    }
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    formatExplanation(explanation) {
        // Simple markdown-like formatting
        return explanation
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`(.*?)`/g, '<code>$1</code>')
            .replace(/\n/g, '<br>');
    }
    async deleteExplanation(id) {
        if (!confirm('Are you sure you want to delete this explanation?')) {
            return;
        }
        try {
            if (window.electronAPI) {
                const result = await window.electronAPI.deleteExplanation(id);
                if (result.success) {
                    this.explanations = this.explanations.filter(exp => exp.id !== id);
                    this.filteredExplanations = this.filteredExplanations.filter(exp => exp.id !== id);
                    if (this.selectedExplanation?.id === id) {
                        this.selectedExplanation = null;
                    }
                    this.renderExplanations();
                    this.renderExplanationDetail();
                    this.renderFilters();
                }
                else {
                    alert(`Failed to delete: ${result.error}`);
                }
            }
            else {
                // Fallback for testing
                this.explanations = this.explanations.filter(exp => exp.id !== id);
                this.filteredExplanations = this.filteredExplanations.filter(exp => exp.id !== id);
                if (this.selectedExplanation?.id === id) {
                    this.selectedExplanation = null;
                }
                this.renderExplanations();
                this.renderExplanationDetail();
                this.renderFilters();
            }
        }
        catch (error) {
            console.error('Error deleting explanation:', error);
            alert('Error deleting explanation');
        }
    }
}
// Global functions for HTML onclick handlers
async function exportData() {
    try {
        if (window.electronAPI) {
            const result = await window.electronAPI.exportExplanations('json');
            if (result.success) {
                const blob = new Blob([result.data], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'code-explanations.json';
                a.click();
                URL.revokeObjectURL(url);
            }
            else {
                alert(`Failed to export: ${result.error}`);
            }
        }
        else {
            alert('Export functionality not available');
        }
    }
    catch (error) {
        console.error('Error exporting data:', error);
        alert('Error exporting data');
    }
}
async function importData() {
    try {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file)
                return;
            const reader = new FileReader();
            reader.onload = async (e) => {
                try {
                    if (window.electronAPI) {
                        const result = await window.electronAPI.importExplanations(e.target.result);
                        if (result.success) {
                            alert(`Successfully imported ${result.data} explanations`);
                            // Reload explanations
                            await notebook.loadExplanations();
                            notebook.renderExplanations();
                            notebook.renderFilters();
                        }
                        else {
                            alert(`Failed to import: ${result.error}`);
                        }
                    }
                    else {
                        alert('Import functionality not available');
                    }
                }
                catch (error) {
                    console.error('Error importing data:', error);
                    alert('Error importing data');
                }
            };
            reader.readAsText(file);
        };
        input.click();
    }
    catch (error) {
        console.error('Error setting up import:', error);
        alert('Error setting up import');
    }
}
// Initialize notebook when page loads
let notebook;
document.addEventListener('DOMContentLoaded', () => {
    notebook = new Notebook();
});

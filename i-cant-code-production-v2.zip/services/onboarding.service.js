"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.onboardingService = void 0;
class OnboardingService {
    constructor() {
        this.STORAGE_KEY = 'i-cant-code-user-profile';
        this.ONBOARDING_COMPLETED_KEY = 'i-cant-code-onboarding-completed';
        this.ANALYTICS_KEY = 'i-cant-code-analytics';
        this.USER_ID_KEY = 'i-cant-code-user-id';
        this.analyticsEndpoint = 'https://api.icantcode.app/analytics'; // Replace with your actual endpoint
        this.isOnline = navigator.onLine;
        // Listen for online/offline status changes
        window.addEventListener('online', () => {
            this.isOnline = true;
            this.flushPendingAnalytics();
        });
        window.addEventListener('offline', () => {
            this.isOnline = false;
        });
    }
    /**
     * Generate a unique user ID
     */
    generateUserId() {
        const existingId = localStorage.getItem(this.USER_ID_KEY);
        if (existingId)
            return existingId;
        const userId = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem(this.USER_ID_KEY, userId);
        return userId;
    }
    /**
     * Get system information for analytics
     */
    getSystemInfo() {
        return {
            platform: navigator.platform,
            userAgent: navigator.userAgent,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            language: navigator.language,
            screenResolution: `${screen.width}x${screen.height}`,
            colorDepth: screen.colorDepth,
            memory: performance.memory ? {
                usedJSHeapSize: performance.memory.usedJSHeapSize,
                totalJSHeapSize: performance.memory.totalJSHeapSize
            } : null
        };
    }
    /**
     * Send analytics data to server
     */
    async sendAnalytics(event) {
        if (!this.isOnline) {
            // Store offline for later
            this.storePendingAnalytics(event);
            return;
        }
        try {
            const response = await fetch(this.analyticsEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    ...event,
                    timestamp: event.timestamp.toISOString(),
                    systemInfo: this.getSystemInfo()
                })
            });
            if (!response.ok) {
                throw new Error(`Analytics request failed: ${response.status}`);
            }
            console.log('Analytics sent successfully:', event.eventType);
        }
        catch (error) {
            console.error('Failed to send analytics:', error);
            // Store for retry later
            this.storePendingAnalytics(event);
        }
    }
    /**
     * Store analytics events for offline/retry
     */
    storePendingAnalytics(event) {
        try {
            const pending = JSON.parse(localStorage.getItem('i-cant-code-pending-analytics') || '[]');
            pending.push(event);
            localStorage.setItem('i-cant-code-pending-analytics', JSON.stringify(pending));
        }
        catch (error) {
            console.error('Failed to store pending analytics:', error);
        }
    }
    /**
     * Send pending analytics when back online
     */
    async flushPendingAnalytics() {
        try {
            const pending = JSON.parse(localStorage.getItem('i-cant-code-pending-analytics') || '[]');
            if (pending.length === 0)
                return;
            for (const event of pending) {
                await this.sendAnalytics(event);
            }
            // Clear pending analytics
            localStorage.removeItem('i-cant-code-pending-analytics');
            console.log('Pending analytics flushed successfully');
        }
        catch (error) {
            console.error('Failed to flush pending analytics:', error);
        }
    }
    /**
     * Track app launch
     */
    trackAppLaunch() {
        const event = {
            eventType: 'app_launched',
            timestamp: new Date(),
            userId: this.generateUserId(),
            data: {
                sessionId: Date.now().toString(),
                previousLaunch: this.getUserProfile()?.lastActive || null
            }
        };
        this.sendAnalytics(event);
        this.updateUserActivity();
    }
    /**
     * Track session start
     */
    trackSessionStart() {
        const event = {
            eventType: 'session_started',
            timestamp: new Date(),
            userId: this.generateUserId(),
            data: {
                sessionId: Date.now().toString()
            }
        };
        this.sendAnalytics(event);
        // Update profile
        const profile = this.getUserProfile();
        if (profile) {
            profile.analytics.lastSessionStart = new Date();
            profile.analytics.totalSessions += 1;
            this.saveUserProfile(profile);
        }
    }
    /**
     * Track session end
     */
    trackSessionEnd() {
        const event = {
            eventType: 'session_ended',
            timestamp: new Date(),
            userId: this.generateUserId(),
            data: {
                sessionId: Date.now().toString(),
                duration: this.calculateSessionDuration()
            }
        };
        this.sendAnalytics(event);
        // Update profile
        const profile = this.getUserProfile();
        if (profile) {
            profile.analytics.lastSessionEnd = new Date();
            this.saveUserProfile(profile);
        }
    }
    /**
     * Track explanation request
     */
    trackExplanationRequest(language, codeLength) {
        const event = {
            eventType: 'explanation_requested',
            timestamp: new Date(),
            userId: this.generateUserId(),
            data: {
                language,
                codeLength,
                sessionId: Date.now().toString()
            }
        };
        this.sendAnalytics(event);
        // Update profile
        const profile = this.getUserProfile();
        if (profile) {
            profile.analytics.totalExplanations += 1;
            this.saveUserProfile(profile);
        }
    }
    /**
     * Calculate current session duration
     */
    calculateSessionDuration() {
        const profile = this.getUserProfile();
        if (!profile?.analytics.lastSessionStart)
            return 0;
        return Date.now() - profile.analytics.lastSessionStart.getTime();
    }
    /**
     * Check if user has completed onboarding
     */
    hasCompletedOnboarding() {
        try {
            const completed = localStorage.getItem(this.ONBOARDING_COMPLETED_KEY);
            return completed === 'true';
        }
        catch (error) {
            console.error('Error checking onboarding status:', error);
            return false;
        }
    }
    /**
     * Mark onboarding as completed
     */
    markOnboardingCompleted() {
        try {
            localStorage.setItem(this.ONBOARDING_COMPLETED_KEY, 'true');
        }
        catch (error) {
            console.error('Error marking onboarding completed:', error);
        }
    }
    /**
     * Save user onboarding data
     */
    async saveOnboardingData(data) {
        try {
            const onboardingData = {
                ...data,
                completedAt: new Date(),
                appVersion: '1.0.0',
                ...this.getSystemInfo()
            };
            const userProfile = {
                onboarding: onboardingData,
                lastActive: new Date(),
                usageCount: 0,
                favoriteLanguages: [],
                analytics: {
                    firstLaunch: new Date(),
                    totalSessions: 1,
                    totalExplanations: 0,
                    averageSessionDuration: 0,
                    lastSessionStart: new Date(),
                    lastSessionEnd: new Date()
                }
            };
            this.saveUserProfile(userProfile);
            this.markOnboardingCompleted();
            // Track onboarding completion
            const event = {
                eventType: 'onboarding_completed',
                timestamp: new Date(),
                userId: this.generateUserId(),
                data: {
                    codingLevel: data.codingLevel,
                    agreedToTerms: data.agreedToTerms
                }
            };
            await this.sendAnalytics(event);
            console.log('Onboarding data saved successfully:', onboardingData);
        }
        catch (error) {
            console.error('Error saving onboarding data:', error);
        }
    }
    /**
     * Save user profile
     */
    saveUserProfile(profile) {
        try {
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(profile));
        }
        catch (error) {
            console.error('Error saving user profile:', error);
        }
    }
    /**
     * Get user profile data
     */
    getUserProfile() {
        try {
            const stored = localStorage.getItem(this.STORAGE_KEY);
            if (!stored)
                return null;
            const profile = JSON.parse(stored);
            // Convert date strings back to Date objects
            profile.onboarding.completedAt = new Date(profile.onboarding.completedAt);
            profile.lastActive = new Date(profile.lastActive);
            profile.analytics.firstLaunch = new Date(profile.analytics.firstLaunch);
            profile.analytics.lastSessionStart = new Date(profile.analytics.lastSessionStart);
            profile.analytics.lastSessionEnd = new Date(profile.analytics.lastSessionEnd);
            return profile;
        }
        catch (error) {
            console.error('Error getting user profile:', error);
            return null;
        }
    }
    /**
     * Update user activity
     */
    updateUserActivity() {
        try {
            const profile = this.getUserProfile();
            if (profile) {
                profile.lastActive = new Date();
                profile.usageCount += 1;
                this.saveUserProfile(profile);
            }
        }
        catch (error) {
            console.error('Error updating user activity:', error);
        }
    }
    /**
     * Update favorite languages
     */
    updateFavoriteLanguages(languages) {
        try {
            const profile = this.getUserProfile();
            if (profile) {
                profile.favoriteLanguages = languages;
                this.saveUserProfile(profile);
            }
        }
        catch (error) {
            console.error('Error updating favorite languages:', error);
        }
    }
    /**
     * Reset onboarding (for testing or user preference)
     */
    resetOnboarding() {
        try {
            localStorage.removeItem(this.ONBOARDING_COMPLETED_KEY);
            localStorage.removeItem(this.STORAGE_KEY);
            localStorage.removeItem(this.USER_ID_KEY);
            localStorage.removeItem('i-cant-code-pending-analytics');
            console.log('Onboarding reset successfully');
        }
        catch (error) {
            console.error('Error resetting onboarding:', error);
        }
    }
    /**
     * Export user data (for GDPR compliance)
     */
    exportUserData() {
        try {
            const profile = this.getUserProfile();
            const pendingAnalytics = localStorage.getItem('i-cant-code-pending-analytics');
            const exportData = {
                profile,
                pendingAnalytics: pendingAnalytics ? JSON.parse(pendingAnalytics) : [],
                exportDate: new Date().toISOString()
            };
            return JSON.stringify(exportData, null, 2);
        }
        catch (error) {
            console.error('Error exporting user data:', error);
            return '';
        }
    }
    /**
     * Clear all user data
     */
    clearAllUserData() {
        try {
            localStorage.removeItem(this.ONBOARDING_COMPLETED_KEY);
            localStorage.removeItem(this.STORAGE_KEY);
            localStorage.removeItem(this.USER_ID_KEY);
            localStorage.removeItem('i-cant-code-pending-analytics');
            console.log('All user data cleared successfully');
        }
        catch (error) {
            console.error('Error clearing user data:', error);
        }
    }
    /**
     * Get analytics summary
     */
    getAnalyticsSummary() {
        try {
            const profile = this.getUserProfile();
            if (!profile)
                return null;
            return {
                totalSessions: profile.analytics.totalSessions,
                totalExplanations: profile.analytics.totalExplanations,
                averageSessionDuration: profile.analytics.averageSessionDuration,
                firstLaunch: profile.analytics.firstLaunch,
                lastActive: profile.lastActive,
                favoriteLanguages: profile.favoriteLanguages
            };
        }
        catch (error) {
            console.error('Error getting analytics summary:', error);
            return null;
        }
    }
}
exports.onboardingService = new OnboardingService();

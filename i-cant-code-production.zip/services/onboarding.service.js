"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.onboardingService = void 0;
class OnboardingService {
    constructor() {
        this.STORAGE_KEY = 'i-cant-code-user-profile';
        this.ONBOARDING_COMPLETED_KEY = 'i-cant-code-onboarding-completed';
    }
    /**
     * Check if user has completed onboarding
     */
    hasCompletedOnboarding() {
        try {
            const completed = localStorage.getItem(this.ONBOARDING_COMPLETED_KEY);
            return completed === 'true';
        }
        catch (error) {
            console.error('Error checking onboarding status:', error);
            return false;
        }
    }
    /**
     * Mark onboarding as completed
     */
    markOnboardingCompleted() {
        try {
            localStorage.setItem(this.ONBOARDING_COMPLETED_KEY, 'true');
        }
        catch (error) {
            console.error('Error marking onboarding completed:', error);
        }
    }
    /**
     * Save user onboarding data
     */
    saveOnboardingData(data) {
        try {
            const onboardingData = {
                ...data,
                completedAt: new Date(),
                appVersion: '1.0.0' // You can make this dynamic
            };
            const userProfile = {
                onboarding: onboardingData,
                lastActive: new Date(),
                usageCount: 0,
                favoriteLanguages: []
            };
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(userProfile));
            this.markOnboardingCompleted();
            console.log('Onboarding data saved successfully:', onboardingData);
        }
        catch (error) {
            console.error('Error saving onboarding data:', error);
        }
    }
    /**
     * Get user profile data
     */
    getUserProfile() {
        try {
            const stored = localStorage.getItem(this.STORAGE_KEY);
            if (!stored)
                return null;
            const profile = JSON.parse(stored);
            // Convert date strings back to Date objects
            profile.onboarding.completedAt = new Date(profile.onboarding.completedAt);
            profile.lastActive = new Date(profile.lastActive);
            return profile;
        }
        catch (error) {
            console.error('Error getting user profile:', error);
            return null;
        }
    }
    /**
     * Update user activity
     */
    updateUserActivity() {
        try {
            const profile = this.getUserProfile();
            if (profile) {
                profile.lastActive = new Date();
                profile.usageCount += 1;
                localStorage.setItem(this.STORAGE_KEY, JSON.stringify(profile));
            }
        }
        catch (error) {
            console.error('Error updating user activity:', error);
        }
    }
    /**
     * Update favorite languages
     */
    updateFavoriteLanguages(languages) {
        try {
            const profile = this.getUserProfile();
            if (profile) {
                profile.favoriteLanguages = languages;
                localStorage.setItem(this.STORAGE_KEY, JSON.stringify(profile));
            }
        }
        catch (error) {
            console.error('Error updating favorite languages:', error);
        }
    }
    /**
     * Reset onboarding (for testing or user preference)
     */
    resetOnboarding() {
        try {
            localStorage.removeItem(this.ONBOARDING_COMPLETED_KEY);
            localStorage.removeItem(this.STORAGE_KEY);
            console.log('Onboarding reset successfully');
        }
        catch (error) {
            console.error('Error resetting onboarding:', error);
        }
    }
    /**
     * Export user data (for GDPR compliance)
     */
    exportUserData() {
        try {
            const profile = this.getUserProfile();
            return JSON.stringify(profile, null, 2);
        }
        catch (error) {
            console.error('Error exporting user data:', error);
            return '';
        }
    }
    /**
     * Clear all user data
     */
    clearAllUserData() {
        try {
            localStorage.removeItem(this.ONBOARDING_COMPLETED_KEY);
            localStorage.removeItem(this.STORAGE_KEY);
            console.log('All user data cleared successfully');
        }
        catch (error) {
            console.error('Error clearing user data:', error);
        }
    }
}
exports.onboardingService = new OnboardingService();
